// Authentication Module
import { 
    auth, 
    database,
    googleProvider,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signInWithPopup,
    signOut,
    onAuthStateChanged,
    updateProfile,
    ref,
    set,
    get
} from './firebase-config.js';

// Admin email (change this to your admin email)
const ADMIN_EMAIL = 'admin@frutigerworld.com';

// Current user state
let currentUser = null;
let userData = null;

// DOM Elements
const authModal = document.getElementById('authModal');
const gameInterface = document.getElementById('gameInterface');
const userBar = document.getElementById('userBar');

// Auth state listener
onAuthStateChanged(auth, async (user) => {
    if (user) {
        currentUser = user;
        await loadUserData(user.uid);
        showGameInterface();
        updateUserBar();
        
        // Initialize world
        if (window.worldManager) {
            window.worldManager.init(user);
        }
        if (window.chatManager) {
            window.chatManager.init(user);
        }
        if (window.avatarManager) {
            window.avatarManager.init(user);
        }
    } else {
        currentUser = null;
        userData = null;
        showAuthModal();
    }
});

// Load user data from database
async function loadUserData(uid) {
    try {
        const userRef = ref(database, `users/${uid}`);
        const snapshot = await get(userRef);
        
        if (snapshot.exists()) {
            userData = snapshot.val();
        } else {
            // Create new user data
            userData = createDefaultUserData();
            await set(userRef, userData);
        }
        
        // Check if admin
        if (currentUser.email === ADMIN_EMAIL) {
            userData.isAdmin = true;
            userData.pets = ['clownfish', 'dolphin'];
            userData.equippedPet = userData.equippedPet || 'clownfish';
            await set(userRef, userData);
        }
    } catch (error) {
        console.error('Error loading user data:', error);
        userData = createDefaultUserData();
    }
}

// Create default user data
function createDefaultUserData() {
    return {
        color: 'aqua',
        pets: [],
        equippedPet: null,
        aquariumTime: 0,
        isAdmin: false,
        unlockedClownfish: false,
        unlockedDolphin: false,
        joinedAt: Date.now()
    };
}

// Show auth modal
function showAuthModal() {
    authModal.classList.remove('hidden');
    gameInterface.classList.add('hidden');
    userBar.classList.add('hidden');
}

// Show game interface
function showGameInterface() {
    authModal.classList.add('hidden');
    gameInterface.classList.remove('hidden');
    userBar.classList.remove('hidden');
}

// Update user bar
function updateUserBar() {
    if (!currentUser) return;
    
    document.getElementById('userName').textContent = currentUser.displayName || 'User';
    const avatarEl = document.getElementById('userAvatarSmall');
    avatarEl.setAttribute('data-color', userData?.color || 'aqua');
}

// Email/Password Registration
document.getElementById('registerBtn')?.addEventListener('click', async () => {
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim();
    const password = document.getElementById('registerPassword').value;
    const color = document.querySelector('.color-option.selected')?.dataset.color || 'aqua';
    
    if (!name || !email || !password) {
        alert('Please fill in all fields');
        return;
    }
    
    if (password.length < 6) {
        alert('Password must be at least 6 characters');
        return;
    }
    
    try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await updateProfile(userCredential.user, { displayName: name });
        
        // Create user data
        const userData = {
            color: color,
            pets: [],
            equippedPet: null,
            aquariumTime: 0,
            isAdmin: email === ADMIN_EMAIL,
            unlockedClownfish: email === ADMIN_EMAIL,
            unlockedDolphin: email === ADMIN_EMAIL,
            joinedAt: Date.now()
        };
        
        if (email === ADMIN_EMAIL) {
            userData.pets = ['clownfish', 'dolphin'];
            userData.equippedPet = 'clownfish';
        }
        
        await set(ref(database, `users/${userCredential.user.uid}`), userData);
        
    } catch (error) {
        alert('Registration error: ' + error.message);
    }
});

// Email/Password Login
document.getElementById('loginBtn')?.addEventListener('click', async () => {
    const email = document.getElementById('loginEmail').value.trim();
    const password = document.getElementById('loginPassword').value;
    
    if (!email || !password) {
        alert('Please enter email and password');
        return;
    }
    
    try {
        await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
        alert('Login error: ' + error.message);
    }
});

// Google Sign In
document.getElementById('googleSignIn')?.addEventListener('click', async () => {
    try {
        const result = await signInWithPopup(auth, googleProvider);
        const user = result.user;
        
        // Check if new user
        const userRef = ref(database, `users/${user.uid}`);
        const snapshot = await get(userRef);
        
        if (!snapshot.exists()) {
            const userData = {
                color: 'aqua',
                pets: [],
                equippedPet: null,
                aquariumTime: 0,
                isAdmin: user.email === ADMIN_EMAIL,
                unlockedClownfish: user.email === ADMIN_EMAIL,
                unlockedDolphin: user.email === ADMIN_EMAIL,
                joinedAt: Date.now()
            };
            
            if (user.email === ADMIN_EMAIL) {
                userData.pets = ['clownfish', 'dolphin'];
                userData.equippedPet = 'clownfish';
            }
            
            await set(userRef, userData);
        }
    } catch (error) {
        alert('Google sign-in error: ' + error.message);
    }
});

// Logout
document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    try {
        await signOut(auth);
    } catch (error) {
        console.error('Logout error:', error);
    }
});

// Color picker selection
document.querySelectorAll('.color-picker .color-option').forEach(option => {
    option.addEventListener('click', () => {
        document.querySelectorAll('.color-picker .color-option').forEach(o => o.classList.remove('selected'));
        option.classList.add('selected');
    });
});

// Select first color by default
document.querySelector('.color-picker .color-option')?.classList.add('selected');

// Tab switching
document.querySelectorAll('.auth-tab').forEach(tab => {
    tab.addEventListener('click', () => {
        const targetTab = tab.dataset.tab;
        
        document.querySelectorAll('.auth-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        
        document.getElementById('loginForm')?.classList.add('hidden');
        document.getElementById('registerForm')?.classList.add('hidden');
        
        if (targetTab === 'login') {
            document.getElementById('loginForm')?.classList.remove('hidden');
        } else {
            document.getElementById('registerForm')?.classList.remove('hidden');
        }
    });
});

// Getters
export function getCurrentUser() { return currentUser; }
export function getUserData() { return userData; }
export function updateUserData(newData) { userData = { ...userData, ...newData }; }
export { ADMIN_EMAIL };