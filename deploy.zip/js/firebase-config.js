// Firebase Configuration
import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js';
import { 
    getAuth, 
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signInWithPopup,
    GoogleAuthProvider,
    signOut,
    onAuthStateChanged,
    updateProfile
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js';
import { 
    getDatabase, 
    ref, 
    set, 
    get, 
    onValue, 
    off,
    push,
    update,
    remove,
    onDisconnect 
} from 'https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js';

// Firebase configuration - Using a demo project config
// In production, replace with your actual Firebase config
const firebaseConfig = {
    apiKey: "AIzaSyDemoKeyForFrutigerWorld123456",
    authDomain: "frutiger-world-demo.firebaseapp.com",
    databaseURL: "https://frutiger-world-demo-default-rtdb.firebaseio.com",
    projectId: "frutiger-world-demo",
    storageBucket: "frutiger-world-demo.appspot.com",
    messagingSenderId: "123456789012",
    appId: "1:123456789012:web:abcdef1234567890"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// Export everything
export { 
    app, 
    auth, 
    database, 
    googleProvider,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signInWithPopup,
    signOut,
    onAuthStateChanged,
    updateProfile,
    ref,
    set,
    get,
    onValue,
    off,
    push,
    update,
    remove,
    onDisconnect
};